chrome.runtime.onMessage.addListener((function(e,n,o){"updateUrl"==e.action&&o({url:window.location.href})}));
//# sourceMappingURL=contentScript.js.map